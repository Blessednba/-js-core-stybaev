import { describe, expect, it } from "vitest";
import { Store, SortedStore } from "../src/Store.js";

describe("Store", () => {
  it("adds and finds an item", () => {
    const store = new Store();

    store.add({ name: "Book", price: 1000, qty: 2 });

    expect(store.find("Book")).toEqual({
      name: "Book",
      price: 1000,
      qty: 2
    });
  });

  it("calculates total", () => {
    const store = new Store([
      { name: "Book", price: 1000, qty: 2 },
      { name: "Pen", price: 200, qty: 5 }
    ]);

    expect(store.total()).toBe(3000);
  });

  it("returns zero for empty store", () => {
    expect(new Store().total()).toBe(0);
  });

  it("supports zero quantity", () => {
    const store = new Store([
      { name: "Empty", price: 500, qty: 0 }
    ]);

    expect(store.total()).toBe(0);
  });

  it("removes an item", () => {
    const store = new Store([
      { name: "Book", price: 1000, qty: 1 }
    ]);

    expect(store.remove("Book")).toBe(true);
    expect(store.find("Book")).toBeUndefined();
  });

  it("returns false for missing item", () => {
    expect(new Store().remove("Missing")).toBe(false);
  });

  it("rejects negative quantity", () => {
    expect(() => new Store().add({
      name: "Book",
      price: 1000,
      qty: -1
    })).toThrow(TypeError);
  });

  it("creates Store through static method", () => {
    const store = Store.from([
      { name: "Phone", price: 100000, qty: 1 }
    ]);

    expect(store).toBeInstanceOf(Store);
    expect(store.total()).toBe(100000);
  });
});

describe("SortedStore", () => {
  it("inherits from Store", () => {
    const store = new SortedStore();
    expect(store).toBeInstanceOf(Store);
  });

  it("sorts items by price", () => {
    const store = new SortedStore([
      { name: "Expensive", price: 3000, qty: 1 },
      { name: "Cheap", price: 500, qty: 1 },
      { name: "Middle", price: 1500, qty: 1 }
    ]);

    expect(store.items.map(item => item.name)).toEqual([
      "Cheap",
      "Middle",
      "Expensive"
    ]);
  });

  it("keeps Store total behavior", () => {
    const store = new SortedStore([
      { name: "A", price: 100, qty: 2 },
      { name: "B", price: 50, qty: 4 }
    ]);

    expect(store.total()).toBe(400);
  });
});

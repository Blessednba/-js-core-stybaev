import { describe, expect, it } from "vitest";
import {
  unique,
  groupBy,
  chunk,
  deepClone,
  memoize,
  counter
} from "../src/functions.js";

describe("unique", () => {
  it("removes duplicates", () => {
    expect(unique([1, 2, 2, 3, 1])).toEqual([1, 2, 3]);
  });

  it("works with an empty array", () => {
    expect(unique([])).toEqual([]);
  });

  it("throws for wrong type", () => {
    expect(() => unique("hello")).toThrow(TypeError);
  });
});

describe("groupBy", () => {
  const users = [
    { name: "Ali", age: 20 },
    { name: "Dana", age: 21 },
    { name: "Ayan", age: 20 }
  ];

  it("groups objects by key", () => {
    expect(groupBy(users, user => user.age)).toEqual({
      20: [
        { name: "Ali", age: 20 },
        { name: "Ayan", age: 20 }
      ],
      21: [{ name: "Dana", age: 21 }]
    });
  });

  it("works with an empty array", () => {
    expect(groupBy([], item => item)).toEqual({});
  });

  it("throws when keyFn is invalid", () => {
    expect(() => groupBy(users, "age")).toThrow(TypeError);
  });
});

describe("chunk", () => {
  it("splits an array", () => {
    expect(chunk([1, 2, 3, 4, 5], 2)).toEqual([
      [1, 2],
      [3, 4],
      [5]
    ]);
  });

  it("works with an empty array", () => {
    expect(chunk([], 3)).toEqual([]);
  });

  it("rejects zero size", () => {
    expect(() => chunk([1, 2], 0)).toThrow(RangeError);
  });
});

describe("deepClone", () => {
  it("clones nested objects and arrays", () => {
    const original = {
      user: { name: "Nurzhan" },
      scores: [10, 20]
    };

    const copy = deepClone(original);

    expect(copy).toEqual(original);
    expect(copy).not.toBe(original);
    expect(copy.user).not.toBe(original.user);
    expect(copy.scores).not.toBe(original.scores);
  });

  it("clones Date", () => {
    const date = new Date("2026-09-30");
    const copy = deepClone(date);

    expect(copy).toEqual(date);
    expect(copy).not.toBe(date);
  });

  it("keeps zero unchanged", () => {
    expect(deepClone(0)).toBe(0);
  });
});

describe("memoize", () => {
  it("caches the result", () => {
    let calls = 0;

    const add = memoize((a, b) => {
      calls += 1;
      return a + b;
    });

    expect(add(2, 3)).toBe(5);
    expect(add(2, 3)).toBe(5);
    expect(calls).toBe(1);
  });

  it("throws for wrong type", () => {
    expect(() => memoize(123)).toThrow(TypeError);
  });
});

describe("counter", () => {
  it("increments and decrements", () => {
    const count = counter();

    expect(count.value).toBe(0);
    expect(count.inc()).toBe(1);
    expect(count.inc()).toBe(2);
    expect(count.dec()).toBe(1);
  });

  it("supports a starting value", () => {
    const count = counter(10);

    expect(count.value).toBe(10);
    expect(count.dec()).toBe(9);
  });
});

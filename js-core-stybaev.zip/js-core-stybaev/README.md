# js-core-stybaev

Lab 4 — JavaScript functions, closures, classes and unit tests.

## How to run

Install dependencies:

```bash
npm i
```

Run all tests:

```bash
npm test
```

## Functions

The project contains six required functions:

- `unique(arr)`
- `groupBy(arr, keyFn)`
- `chunk(arr, size)`
- `deepClone(obj)`
- `memoize(fn)`
- `counter()`

## Closures in my code

I used closures in the `memoize` and `counter` functions. A closure allows an inner function to remember variables from the outer function after the outer function has finished. In `counter`, the variable `value` is private because only `inc`, `dec` and the getter can access it. Each call to `counter()` creates its own separate `value`. In `memoize`, the `cache` Map is stored inside the closure. The returned function can use this cache on later calls and therefore avoid calculating the same result again.

## Tests

The project uses Vitest and contains more than 12 unit tests, including empty arrays, invalid types and zero values.

Run:

```bash
npm test
```

## AI tools

ChatGPT was used to help create and organize the code. The final code was reviewed and adapted for this assignment.
